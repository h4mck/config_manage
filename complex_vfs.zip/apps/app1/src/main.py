def main():
    print("App1 main")