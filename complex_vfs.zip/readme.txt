Complex VFS Structure
Multiple levels of folders