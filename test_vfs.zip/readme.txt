Test VFS for command demonstration
